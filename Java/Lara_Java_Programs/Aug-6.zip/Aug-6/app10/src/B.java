class B
{
	public static void main(String[] args) 
	{
		
		System.out.println("main begin");
		for (int i = 3;i <= 5 ; i++ )
		{
		System.out.println("loop body:"+i);
		System.out.println("................");
		}
		System.out.println("main end");
	}
}
