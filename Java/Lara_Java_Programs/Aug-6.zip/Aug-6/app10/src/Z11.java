class Z11

{
	public static void main(String[] args) 
	{	
		{
			System.out.println("block1");
			System.out.println("block1");
			System.out.println("block1");
			System.out.println("block1");
			System.out.println("block1");
		}
		
		{
			System.out.println("block2");
			System.out.println("block2");
			System.out.println("block2");
			System.out.println("block2");
			System.out.println("block2");
		}
			
	}
}
