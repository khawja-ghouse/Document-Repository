class Z13
{
	public static void main(String[] args) 
	{	
		
			int i = 10;
		{
			System.out.println("block1" + 10);
			System.out.println("block1");
			System.out.println("block1");
			System.out.println("block1");
			System.out.println("block1");
		}
		i = 30;
		
		{
			System.out.println("block2"+ i );
			System.out.println("block2");
			System.out.println("block2");
			System.out.println("block2");
			System.out.println("block2");
		}
			
	}
}
