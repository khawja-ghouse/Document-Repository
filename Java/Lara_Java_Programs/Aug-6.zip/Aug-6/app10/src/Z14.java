class  Z14
{
	public static void main(String[] args) 
	{
		if (false);
		{
			System.out.println("if stm1");
			System.out.println("if stm2");
			System.out.println("if stm3");
		}
		System.out.println("main end");
	}
}
