class B
{
	public static void test()
	{
		System.out.println("test");
	}
	public static void main(String[] args) 
	{
		System.out.println("main");
	}
}
