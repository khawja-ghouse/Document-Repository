class L 
{
	public static void main(String[] args) 
	{
		System.out.println("main");
		return;
	}
}
//every method should have a return type.Return type should be specified before the name of the method;
//there are three different return type;
//1 void
//2 Any premitive datatype
//3 any derived datatype
//if the return type is void it should not return a value 
