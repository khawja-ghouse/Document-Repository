class N
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		return;//return stsm should always be the last stsm in the current block;
		System.out.println("main end");
		
	}
}