class Q
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if (true)
		{
			
			return;
			System.out.println("from if");
		}
		System.out.println("main end");
		
	}
}