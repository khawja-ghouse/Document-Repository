class W
{
	public static void main(String[] args) 
	{	
		System.out.println("main1");
		test();
		System.out.println("main2");
	}
	public static int test()
	{
		System.out.println("from test");
	}	
}
/*
primitive data types(Any datatype that is already defined in a programming language is called Primitive dataType)
--------------------
byte 
short
int 
long
float
double
boolean
char
*/