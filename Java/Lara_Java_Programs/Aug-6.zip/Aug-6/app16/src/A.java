class A 
{
	static int i ;//property , field,global variable,attribute
	public static void main(String[] args) 
	{
		System.out.println("main "+i);
	}
}
