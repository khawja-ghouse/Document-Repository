class B 
{
	static byte i;
	static short j;
	static  int k;
	static long l;
	static float n;
	static double m;
	static char o;
	static String q;
	static boolean p;
	public static void main(String[] args) 
	{
		System.out.println("byte:"+i);
		System.out.println("short:"+j);
		System.out.println("int "+ k);
		System.out.println("long:"+l);
		System.out.println("float"+n);
		System.out.println("double"+m);
		System.out.println("char"+ o);
		System.out.println("string"+q);
		System.out.println("boolean"+p);
	}
}
