class C 
{
	static int i;
	static int j;
	public static void main(String[] args) 
	{
		System.out.println(i+","+j);
	}
}
