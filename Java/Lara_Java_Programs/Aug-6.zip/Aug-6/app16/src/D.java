class  D
{
	static int i , j;
	public static void main(String[] args) 
	{
		System.out.println(i+","+j);
	}
}
