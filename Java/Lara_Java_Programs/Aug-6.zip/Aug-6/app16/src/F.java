class  F
{
	static int i,j = 10,k;
	public static void main(String[] args) 
	{
		System.out.println(i+","+j+","+k);
	}
}
