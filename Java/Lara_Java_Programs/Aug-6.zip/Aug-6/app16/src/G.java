class  G
{
	static int i;
	public static void main(String[] args) 
	{
		System.out.println("main"+i);
		i = 10;
		System.out.println("main"+i);
		i = 20;
		System.out.println("main"+i);
	}
}
