class  I
{
	static int x;
	static double y;
	public static void main(String[] args) 
	{
		System.out.println("main::"+x+","+y);
	}
}
