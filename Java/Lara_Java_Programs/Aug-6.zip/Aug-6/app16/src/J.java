class  J
{
	static int x;
	static double x;
	public static void main(String[] args) 
	{

		System.out.println(x);//compile time error bec both the global variables are having same name 
	}
}
