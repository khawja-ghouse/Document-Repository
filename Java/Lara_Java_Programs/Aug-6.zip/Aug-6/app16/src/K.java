class  K
{
	static int x;
	static double x;
	public static void main(String[] args) 
	{
		System.out.println("main::");//cmp error even though v are not using th variables
	}
}
