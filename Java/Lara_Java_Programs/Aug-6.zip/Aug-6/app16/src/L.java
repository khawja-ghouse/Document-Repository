class  L
{
	static int x = 30;
	static double x = 4.5;
	public static void main(String[] args) 
	{
		System.out.println("main::");
	}
}
