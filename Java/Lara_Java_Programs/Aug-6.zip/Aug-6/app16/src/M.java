class  M
{
	static int x = 5;
	
	public static void main(String[] args) 
	{
		int x = 10;
		System.out.println("main::" + x);

	}

}
