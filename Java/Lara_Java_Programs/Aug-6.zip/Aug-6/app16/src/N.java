class  N
{
	static int x = 5;
	
	public static void main(String[] args) 
	{
		boolean x = true;
		System.out.println("main::" + x);
	}
}
