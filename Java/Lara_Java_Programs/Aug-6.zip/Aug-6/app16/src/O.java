class O 
{
	public static void main(String[] args) 
	{
		static int x = 5;
		System.out.println("main" + x);
	}
}
