class D 
{
	static
	{
		System.out.println("SIB");
	}
	public static void main(String[] args) 
	{
		System.out.println("main");
	}
}
