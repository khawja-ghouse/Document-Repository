class Q
{
	public static void test() 
	{
		System.out.println("from Q.test");
	}
}
