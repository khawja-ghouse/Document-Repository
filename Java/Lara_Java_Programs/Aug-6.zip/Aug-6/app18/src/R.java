class R 
{
	public static void main(String[] args) 
	{
		System.out.println("main brgin");
		Q.test();
		System.out.println("main end");
	}
}
