class S 
{
	static int i = 20;
}
