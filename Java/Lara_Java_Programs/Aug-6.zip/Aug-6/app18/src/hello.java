class C
{
	static int i;
}
class D
{
	public static void main(String[] args) 
	{
		System.out.println("main"+ C.i);
	}
}
