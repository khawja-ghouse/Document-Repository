class H
{
	
	public static void test()
	{
		System.out.println("test:"+i);
	}
	static int i;
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
	}
}
