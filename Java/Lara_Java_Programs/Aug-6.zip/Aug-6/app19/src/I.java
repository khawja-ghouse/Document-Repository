class I 
{
	static int x;
	static int y = x;
	public static void main(String[] args) 
	{
		System.out.println(x +"," +y);
	}
}
