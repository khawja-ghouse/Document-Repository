class K
{
	static int x;
	static int y;
	static int z = y;
	public static void main(String[] args) 
	{
		System.out.println(x +"," +y+","+z);
	}
}
