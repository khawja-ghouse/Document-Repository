class N
{
	static 
	{
		i =10;
	}
	static int i = 5;
	public static void main(String[] args) 
	{
		System.out.println("main"+i);
	}
}
