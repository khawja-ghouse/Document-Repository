class  A
{
	public static void main(String[] args) 
	{
		int age = 22;
		double weight = 64.5;
		int x = 1;
		double y = 1.0;
		boolean a = true;
		System.out.println(x);
		System.out.println(y);
		System.out.println(a);
		System.out.println("The age is "+age+"and his weight is "+ weight );
	}
}