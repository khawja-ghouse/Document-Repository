class B
{
	void test()
	{
	}
	public static void main(String[] args) 
	{
		test();
	}
}
