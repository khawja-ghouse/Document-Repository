class C
{
	public void test1()
	{
		System.out.println("hello world");
	}
	public static void test2() 
	{
		test1();
	}
}
