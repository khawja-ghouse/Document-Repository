class D
{
	int i;
	static
	{
		System.out.println(i);
	}
}
