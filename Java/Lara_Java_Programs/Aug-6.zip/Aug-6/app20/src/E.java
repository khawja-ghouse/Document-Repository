class E 
{
	void test()
	{
	}
	static
	{
		test();
	}
}
