class F 
{
	int i;
	public static void main(String[] args) 
	{
		F f1 = new F();
		System.out.println(f1.i);
	}
}
