class H
{
	int i;
	public static void main(String[] args) 
	{
		H h1 = new H();
		System.out.println(h1.i);		
		h1.i=10;
		System.out.println(h1.i);		
		h1.i=20;
		System.out.println(h1.i);		
		h1.i=30;
		System.out.println(h1.i);
	}
}
