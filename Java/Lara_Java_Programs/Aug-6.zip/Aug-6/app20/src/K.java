class K
{
	int i;
	public static void main(String[] args) 
	{
		K k1 = new K();
		K k2 = new K();
		K k3 = new K();
		k1.i= 10;
		k2.i= 20;
		k3.i= 30;
		System.out.println(k1.i);
		System.out.println(k2.i);
		System.out.println(k3.i);

			
	}
}
