class L
{
	int i;
	public static void test()
	{
			System.out.println(i);
	}
	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}
