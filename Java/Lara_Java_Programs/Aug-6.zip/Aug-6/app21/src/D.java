class D
{
	int i;
	D()
	{
		i = 100;
	}
	public static void main(String[] args) 
	{
		D d1 = new D();
		System.out.println("main:"+d1.i);
	}
}
