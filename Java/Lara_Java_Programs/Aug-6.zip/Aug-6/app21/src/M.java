class M
{
	public static void main(String[] args) 
	{
		System.out.println("main-begin");
		M obj = new M(100);
		System.out.println("main-end");
	}
}