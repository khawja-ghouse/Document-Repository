class N
{
	N(int i)
	{
	}
	public static void main(String[] args) 
	{
		System.out.println("main-begin");
		N obj = new N();
		System.out.println("main-end");
	}
}