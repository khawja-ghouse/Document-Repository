class S
{
	S()
	{
		this(90,12)
		int i = 10;
		//this(90);
	}
	
	S(int i)
	{

	}	
	
	public static void main(String[] args) 
	{
		System.out.println("main-begin");
		
	}
}