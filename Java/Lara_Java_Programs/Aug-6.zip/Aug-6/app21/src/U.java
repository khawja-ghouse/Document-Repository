class U 
{
	U()
	{
		System.out.println("Hello constructor!");
		//this(990);
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
