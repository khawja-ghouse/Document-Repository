class W 
{
	W(int i)
	{
		this();
	}
	W()
	{
		this(0);
	}

	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
//cmp errror cyclic way recursion is going 
