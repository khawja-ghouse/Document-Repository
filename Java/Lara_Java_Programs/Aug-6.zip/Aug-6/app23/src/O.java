class O
{
	O()
	{
		System.out.println("O()");
	}
	{
		System.out.println("O-IIB");
	}
	public static void main(String[] args)
	{
		O o1 = new O();
			System.out.println("...................");	
		O o2 = new O();
			System.out.println("...................");
	}
}