package pack1;
public class A
{
	int x;
	protected int y;
	public int z;
}               