package pack1;
class  D
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println(a1.x);
		System.out.println(a1.y);
		System.out.println(a1.z);
		C c1 = new C();
		System.out.println(c1.x);
		System.out.println(c1.y);
		System.out.println(c1.z);
	}
}
