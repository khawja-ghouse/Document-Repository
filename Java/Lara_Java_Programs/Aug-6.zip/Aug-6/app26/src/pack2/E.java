package pack2;
class E 
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println("done World!");
	}
}
