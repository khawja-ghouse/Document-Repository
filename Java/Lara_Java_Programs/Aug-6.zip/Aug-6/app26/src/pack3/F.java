package pack3;
class F
{
	public static void main(String[] args) 
	{
		pack1.A a1 = new pack1.A();
		System.out.println("done World!");
	}
}
