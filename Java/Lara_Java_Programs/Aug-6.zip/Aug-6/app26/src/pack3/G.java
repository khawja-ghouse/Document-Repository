package pack3;
import pack1.A;
class G
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println("done World!");
	}
}
