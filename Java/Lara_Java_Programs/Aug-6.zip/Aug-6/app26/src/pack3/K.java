package pack3;
import pack1.A;
class K extends A
{
	public static void main(String[] args) 
	{
		K k1 = new K();
		System.out.println(k1.x);
		System.out.println(k1.y);
		System.out.println(k1.z);
	}
}
