package pack3;
import pack1.A;
class L extends A
{
	public static void main(String[] args) 
	{
		L l1 = new L();
		System.out.println(l1.y);
		System.out.println(l1.z);
	}
}
