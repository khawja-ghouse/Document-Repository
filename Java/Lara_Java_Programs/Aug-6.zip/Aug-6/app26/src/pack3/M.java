package pack3;
public class M extends L
{
	public static void main(String[] args) 
	{
		M m1 = new M();
		System.out.println(m1.y);
		System.out.println(m1.z);
	}
}
