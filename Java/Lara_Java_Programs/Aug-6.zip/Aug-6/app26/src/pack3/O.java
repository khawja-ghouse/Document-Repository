package pack3;
class O extends L
{
	public static void main(String[] args) 
	{
	/*	M m1 = new M();
		System.out.println(m1.y);
		System.out.println(m1.z);*/
		L l1 = new L();
		System.out.println(l1.y);
		System.out.println(l1.z);
	}
}
