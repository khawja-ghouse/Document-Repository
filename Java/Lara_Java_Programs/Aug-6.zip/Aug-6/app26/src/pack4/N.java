package pack4;
import pack3.*;
public class N extends M
{
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println(n1.y);
		System.out.println(n1.z);
	}
}
