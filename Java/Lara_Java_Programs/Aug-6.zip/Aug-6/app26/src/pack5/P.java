package pack5;
import pack4.*;
class P extends N
{
	public static void main(String[] args) 
	{
		/*N n1 = new N();
		System.out.println(n1.y);
		System.out.println(n1.z);*/
		P p1 = new P();
		System.out.println(p1.y);


	}
}