abstract class A
{
	void test1()//implement,defined and concrete method
	{
	}
	abstract void test2();//un-implemented ,un-defined and declared method
}