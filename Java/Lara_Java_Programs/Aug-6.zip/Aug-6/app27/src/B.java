class B
{
	void test1()
	{
	}
	abstract void test2();
}
/*
B.java:1: error: B is not abstract and does not override abstract method test2() in B
 class B
 ^
1 error*/