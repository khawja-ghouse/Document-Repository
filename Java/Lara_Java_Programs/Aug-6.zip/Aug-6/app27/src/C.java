abstract class C
{
	void test1()
	{
	}
	void test2();
}
/*
C.java:6: error: missing method body, or declare abstract
         void test2();
              ^
1 error
*/