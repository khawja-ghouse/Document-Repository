abstract class D
{
	abstract void test1()
	{
	}
	 abstract void test2();
}
/*
D.java:3: error: abstract methods cannot have a body
        abstract void test1()
                      ^
1 error
defined method should be <--defined--> with abstract
*/