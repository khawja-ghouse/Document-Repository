abstract class E
{

	 abstract void test1();
	 abstract void test2();
	 abstract void test3();
	 abstract void test4();
	 abstract void test5();
}
/*
in Abstract class There can be any number of abstract methods or all the methods can be a abstract method
*/