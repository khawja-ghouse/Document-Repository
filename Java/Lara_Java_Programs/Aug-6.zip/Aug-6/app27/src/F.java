abstract class F
{
	void test1()
	{
	}
	void test2()
	{
	}
}
/*
in Abstract class we can define Zero abstract methods ,then declaring the class abstract is very .....optional.....
>>if atleast one abstrat method is present in the class then the class should be abstract
*/