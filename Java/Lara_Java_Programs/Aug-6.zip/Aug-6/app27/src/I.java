abstract class A
{

}
class I
{
	public static void main(String[] args)
	{
		A a1 = null;
		System.out.println("DON");
	}
}
/*

*/