abstract class A
{

}
class J
{
	void test1(A obj)
	{
	}
	public static void main(String[] args)
	{
		System.out.println("DON");
	}
}
/*

*/