abstract class A
{

}
class K
{
	K(A obj)
	{
	}
	public static void main(String[] args)
	{
		System.out.println("DON");
	}
}
/*

*/