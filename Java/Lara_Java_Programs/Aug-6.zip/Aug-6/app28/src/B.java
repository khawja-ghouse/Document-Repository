interface B
{

}
//interface becom a member of the java file 
//for interfaces also the class file is developing
//by default there is a abstract keywod for interface  and that is optional 