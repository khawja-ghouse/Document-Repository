interface C
{
	void test()
	{
	}
}
//cmp error bec interface will not allow any defined method