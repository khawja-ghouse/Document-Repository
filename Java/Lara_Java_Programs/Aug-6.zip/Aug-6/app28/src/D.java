interface D
{
	D()
	{
	}
}