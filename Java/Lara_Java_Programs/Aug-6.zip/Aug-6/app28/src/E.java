interface E
{
	{

	}
	static 
	{
	}
}
//we cant define a IIB,SIB inside a interfaces