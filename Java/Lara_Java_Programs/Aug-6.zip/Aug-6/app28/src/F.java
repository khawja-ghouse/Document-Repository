public interface F
{
	int i = 10;

	void test1();
}

//As only abstract method are allowed and final and constant are by default for varials and abstrct by default for method 
//Every member of the interface is a .......public.... by default is also a public we cannot define private or protected ;
//every attribute of the interface should be initialised 
//interface are used of external projects ..etc hence the members should be public 
//But F is not a public if v want F as a public then we should provid explicitly public interface F 