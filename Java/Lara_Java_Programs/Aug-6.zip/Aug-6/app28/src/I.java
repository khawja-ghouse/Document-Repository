interface I
{
	int m;
}
/*
I.java:3: error: = expected
        int m;
             ^
1 error

we should initialise the attribute m;
 the datatype shu be bef name of the attribute rest of the thing can be in any order

*/