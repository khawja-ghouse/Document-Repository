interface J
{
	void test1();
	abstract void test2();
	public void test3();
	public abstract void test4();
	abstract public void test5();
}

// the return type  shu be bef name of the method  rest of the thing can be in any order
//by default it takes public and abstract