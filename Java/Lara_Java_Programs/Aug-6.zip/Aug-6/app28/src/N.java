interface N
{
	public int i = 10;
	public int j = 10;
	final int k =10;
	final static int m = 10;
	final public static int n = 10;
	int p =10;
}
//By default all the variables are <-----public static final-----> with any order