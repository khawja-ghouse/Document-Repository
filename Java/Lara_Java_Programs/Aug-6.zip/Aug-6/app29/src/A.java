class A 
{
	public static void test()
	{
		System.out.println("test()");
	}
	public static void test(int i, int j)
	{
		System.out.println("test(int i,int j)");
	}
	public static void test(double i)
	{
		System.out.println("test(double)");
	}
}
//overloaded method can have any access specfiers
//same method name  with different method   signature==>overloading