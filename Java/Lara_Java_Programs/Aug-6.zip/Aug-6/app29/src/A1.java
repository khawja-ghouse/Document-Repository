public class A
{
}
public class L
{
}