class B
{
	public static void test()
	{
		System.out.println("test()");
	}
	 void test(int i)
	{
		System.out.println("test(int i)");
	}
}
//overloaded method can have any access specfiers
//same method with different signature==>overloading