interface H
{

	void test();
	void test(int i);
	void test(double i);
	void test(boolean i);
	void test(int  i,int j);
}
