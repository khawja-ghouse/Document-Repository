interface I
{
	protected void test();
}
//interfaces members cannot be provide explicitly  protected or private 