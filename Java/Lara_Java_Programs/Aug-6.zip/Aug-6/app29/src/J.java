interface J
{
	private int x = 200;
}
//interfaces members cannot be provide explicitly  protected or private 