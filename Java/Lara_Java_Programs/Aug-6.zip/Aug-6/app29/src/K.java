class A
{
	public static void main(String[] args)
	{
		System.out.println("main");
	}
}
public class K
{

}
//no matter main method is present or not if  the class is having the access specifier as public then file name 
//should be same as public class name