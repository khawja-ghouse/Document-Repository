class A 
{
	public static void main(String[] args) 
	{
		System.out.println("A.main()");
	}
}
class O
{
	public static void main(String[] args) 
	{
		System.out.println("O.main()");
	}
}
//Any no of classes can have main method in the single java file 