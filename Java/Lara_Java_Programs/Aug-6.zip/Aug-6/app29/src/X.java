class A
{
}
class B extends A
{
}
class C extends B
{
}
class P
{
	 B test()
	{
		 return null;
	}
}
class Q extends P
{
	 B test()
	{
		 return null;
	}
}
class  X
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
