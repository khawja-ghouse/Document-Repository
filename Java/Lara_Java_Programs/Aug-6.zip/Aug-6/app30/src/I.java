class I
{
	public static void main(String[] args) 
	{
		int i = 100;
		byte b1 = (byte)i;
		System.out.println("Hello World!");
	}
}
/*

*/