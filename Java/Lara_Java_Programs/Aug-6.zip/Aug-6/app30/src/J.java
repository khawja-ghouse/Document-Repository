class J
{
	public static void main(String[] args) 
	{
		int i = 129;
		byte b1 = (byte)i;//
		System.out.println(b1);
	}
}
/*

*/