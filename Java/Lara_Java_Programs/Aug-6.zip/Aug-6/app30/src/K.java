class K
{
	public static void main(String[] args) 
	{
		int i = -130;
		byte b1 = (byte)i;
		System.out.println(b1);
	}
}
/*

*/