class L
{
	public static void main(String[] args) 
	{
		
		System.out.println(Short.MIN_VALUE);
		System.out.println(Short.MAX_VALUE);
	}
}
/*

*/