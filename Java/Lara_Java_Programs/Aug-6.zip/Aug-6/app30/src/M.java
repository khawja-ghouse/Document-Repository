class M
{
	public static void main(String[] args) 
	{
		
		int i = 30000;
		short s1 = i;
		System.out.println(s1);
	}
}
/*

*/