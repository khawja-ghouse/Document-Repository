class N
{
	public static void main(String[] args) 
	{
		
		int i = 30000;
		short s1 = (short)i;
		System.out.println(s1);
	}
}
/*

*/