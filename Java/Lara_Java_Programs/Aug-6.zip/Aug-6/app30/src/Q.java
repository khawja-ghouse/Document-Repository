class Q 
{
	public static void main(String[] args) 
	{
		double d1 = 2.5;
		int i = (int)d1;
		System.out.println(i);
	}
}
//2