class R
{
	public static void main(String[] args) 
	{
		int i =100;
		short j = (short)i;
		System.out.println(j);
	}
}
//100