class U
{
	public static void main(String[] args) 
	{
		int i =128;
		short j = (short)(byte)i;
		System.out.println(j);
	}
}