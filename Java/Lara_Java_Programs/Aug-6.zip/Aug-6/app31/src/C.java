class C extends B 
{
	int k;
	void test3()
	{
		System.out.println("from C.test3()");
	}
}
