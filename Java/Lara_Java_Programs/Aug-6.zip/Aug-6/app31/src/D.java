class D extends C 
{
	int l;
	void test4()
	{
		System.out.println("from D.test4()");
	}
}
