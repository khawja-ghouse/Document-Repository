class E extends D 
{
	int m;
	void test5()
	{
		System.out.println("from E.test5()");
	}
}
