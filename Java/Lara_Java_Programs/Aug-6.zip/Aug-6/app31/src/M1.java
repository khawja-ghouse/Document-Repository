class M1 
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		Object obj = new Object();
		D d1 = new D();
		E e1 = new E();
		C c1 = new C();
		B b1 = new B();
		System.out.println("done ");
	}
}
//Here both reference typr is same as class type 