class M16 
{
	public static void main(String[] args) 
	{
		A a1 = new B();
		B b1 = a1;
		System.out.println("done");
	}
}
