class M17
{
	public static void main(String[] args) 
	{
		A a1 = new B();
		B b1 = (B)a1;
		System.out.println("done");
	}
}