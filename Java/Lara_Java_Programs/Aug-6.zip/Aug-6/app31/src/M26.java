class M26
{
	public static void main(String[] args) 
	{
		Object obj = new E();
		A a1 = (A) obj;
		System.out.println("............");
		B b1 = (B) obj;
		System.out.println("............");
		C  c1 = (C) obj;
		System.out.println("............");
		D d1 = (D) obj;
		System.out.println("............");
		E e1 = (E) obj;
		System.out.println("............");
	}
}