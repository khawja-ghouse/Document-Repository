class M27 
{
	public static void main(String[] args) 
	{
		Test.method1(new D());
		System.out.println("Hello World!");
	}
}
