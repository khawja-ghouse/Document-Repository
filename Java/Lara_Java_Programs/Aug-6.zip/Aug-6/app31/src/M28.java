class M28 
{
	public static void main(String[] args) 
	{
		Test.method1(new B());
		System.out.println("Hello World!");
	}
}
