class M36 
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		a1.test1();
		System.out.println(a1.i);
	}
}
//compiler ill check wh is a1 == a1 datatype 
//runtime environment ill be checking where a1 is pointing 
