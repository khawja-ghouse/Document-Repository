class A1
{
	public static void main(String[] args) 
	{
		int k = 9;
		for (int i =9 ;i >= 4 ;)
		{
			for (int j =1;j<=5 ;j++ )
			{ 
					System.out.print(i--);
					
			}
			k--;
			i=k;
			System.out.println();
		}
	}
}
