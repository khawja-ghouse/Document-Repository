class E 
{
	final int i = 10;
	public static void main(String[] args) 
	{
		E e2 = new E();
		e2 = new E();
		System.out.println("Hello World!");
	}
}
