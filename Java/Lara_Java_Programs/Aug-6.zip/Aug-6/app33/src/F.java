class F 
{

	public static void main(String[] args) 
	{
		final int[] x = new int[3];
		//x = new int[4]
		x[2] = 20;
		System.out.println("Hello World!");
	}
}
