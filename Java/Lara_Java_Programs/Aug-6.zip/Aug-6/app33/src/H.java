class H
{
	public static void main(final String[] args) 
	{
		args[0] = "abc";
		System.out.println("Hello!");
	}
}
