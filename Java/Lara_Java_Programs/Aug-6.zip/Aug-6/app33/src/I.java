class I
{
	public static void main(final String[] args) 
	{
		args = null;//this is reintializing 
		System.out.println("Hello!");
	}
}
