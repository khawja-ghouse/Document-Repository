class K 
{
	final int i ;
}
//final variable cannot survive with a default value it cannot be blank