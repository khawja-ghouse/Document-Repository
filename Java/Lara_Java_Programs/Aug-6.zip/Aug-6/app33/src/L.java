class L
{
	final int i = 10;
}
