class M
{
	final int i ;

	M()
	{
		i =20;
	}
}