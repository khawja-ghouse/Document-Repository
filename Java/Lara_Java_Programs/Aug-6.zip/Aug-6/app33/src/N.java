class N
{
	final int i =20;
	N()
	{
		i = 20;
	}
}