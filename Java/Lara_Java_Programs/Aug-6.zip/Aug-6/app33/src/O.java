class O
{
	final int i;
	{
		i = 20;
	}
}