class P
{
	final int i = 20;
	{
		i = 20;
	}
}