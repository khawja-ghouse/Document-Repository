class Q
{
	final int i;
	Q()
	{
		//super calling stmt
		//iib
		i =20;
	}

	{
		i = 10;
	}
}