class R 
{
	final int i = 10;
	public static void main(String[] args) 
	{
		R r1 = new R();
		r1.i = 20;// attempting to re initalize
		System.out.println("Hello !");
	}
}
