class S 
{
	final int i;
	S()
	{
		i = 10;
	}
	S(int x)
	{
		i =20;
	}
}
//No CTE
//it is constant for a perticular object